totalSquareFeet = int(input("enter the total square feet: "))
print("equivalent to", totalSquareFeet/43560, "acres")