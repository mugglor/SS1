miles = int(input("enter the number of miles driven: "))
gas = int(input("enter the gallons of gas used: "))
print("MPG =", miles/gas)