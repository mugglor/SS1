s = 70
print("The distance the car will travel in 6 hours:", s * 6)
print("The distance the car will travel in 10 hours:", s * 10)
print("The distance the car will travel in 15 hours:", s * 15)