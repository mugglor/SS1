c = int (input("enter temperature in Celsius: "))
f = 9/5*c + 32
print("temperature in Fahrenheit", f)