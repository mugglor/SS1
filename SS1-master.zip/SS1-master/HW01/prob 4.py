total = int(input("enter the projected amount of total sales: "))
print("annual profit:", total*0.23)