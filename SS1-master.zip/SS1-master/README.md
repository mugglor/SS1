# SS1
For all the matters of Special Subject 01 of Nguyen Duy Khanh (1801040118) 4C-18
