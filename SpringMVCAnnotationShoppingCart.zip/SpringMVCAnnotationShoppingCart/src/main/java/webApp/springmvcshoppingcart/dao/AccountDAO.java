package webApp.springmvcshoppingcart.dao;

import webApp.springmvcshoppingcart.entity.Account;

public interface AccountDAO {
 
    
    public Account findAccount(String userName );
    
}