frating = open("ratings-small.txt")
books = []
file = frating.readlines()
users = []
userRate = {}
avg_list = []


for line in range(1, len(file), 3):
    books.append(file[line].strip(' \n'))

for user in range(0, len(file), 3):
    users.append(file[user].strip(' \n'))

# remove dupplicated books & users
books = list(dict.fromkeys(books))
users = list(dict.fromkeys(users))

for i in range(len(users)):
    userRate[users[i]] = []

for user in users:

    rating_value = []
    for i in range(len(books)):
        rating_value.append(0)

    for line in range(0, len(file), 3):
        if file[line].strip(' \n') == user:
            for bookInd in range(len(books)):

                if file[line + 1].strip(' \n') == books[bookInd]:
                    rating_value[bookInd] += int(file[line + 2].strip(' \n'))
                    userRate.update({user: rating_value})


rateValue = list(userRate.values())
tup_rate = ()
for bookInd in range(len(books)):
    count = 0
    rate = 0
    tup_rate = list(tup_rate)
    for i in range(len(rateValue)):
        for j in range(len(rateValue[i])):
            if rateValue[i][j] != 0:
                rate += rateValue[i][j]
                count = count + 1
    tup_rate.append(rate / count)

avg_list.append(books)
avg_list.append(tup_rate)


print(userRate)
print(avg_list)


